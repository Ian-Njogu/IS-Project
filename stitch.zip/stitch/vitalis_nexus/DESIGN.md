# Design System Document: Precision Clinical Intelligence

## 1. Overview & Creative North Star

### Creative North Star: "The Clinical Curator"
In the high-stakes environment of organ transplant matching, the UI must do more than display data—it must provide clarity, reduce cognitive load, and command trust. This design system moves away from the "industrial hospital software" aesthetic toward a **High-End Editorial** experience. 

We achieve this through **The Clinical Curator** approach: a layout that feels like a premium medical journal combined with the efficiency of a high-performance cockpit. By leveraging intentional asymmetry, sophisticated tonal layering, and an authoritative typographic scale, we move beyond the generic "blue box" interface into a space of professional prestige.

**The Design Philosophy:**
*   **Intentional Depth:** We use background shifts instead of borders to define space.
*   **Data as Art:** Large, purposeful typography makes critical metrics (blood types, matching scores) the focal point.
*   **Bespoke Asymmetry:** While built on a rigid grid, we break the "template" feel by using varying column widths and overlapping "glass" elements to guide the eye to the most urgent clinical data.

---

## 2. Colors & Surface Logic

The palette is rooted in clinical sterile whites and deep, trustworthy slate blues. To maintain a premium feel, we strictly adhere to a **"No-Line" Rule**.

### The "No-Line" Rule
Sectioning must never be achieved with `1px solid` borders. Instead, boundaries are defined by:
1.  **Background Color Shifts:** A `surface-container-low` (#f0f4f6) section sitting on a `surface` (#f8fafb) background.
2.  **Tonal Transitions:** Using subtle shifts between `surface-container` tiers to denote hierarchy.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers, like stacked sheets of frosted glass.
*   **Base:** `surface` (#f8fafb)
*   **Level 1 (Sections):** `surface-container-low` (#f0f4f6)
*   **Level 2 (Active Cards):** `surface-container-lowest` (#ffffff) to provide a "pop" of clean white against the grey.
*   **Level 3 (Modals/Overlays):** `surface-bright` (#f8fafb) with a backdrop blur.

### Glass & Gradient Implementation
To avoid a flat, "budget" feel, use **Glassmorphism** for floating utility panels (e.g., matching filters). Apply a `backdrop-blur: 12px` to a semi-transparent `surface` color. Main CTAs should use a subtle linear gradient from `primary` (#4e6073) to `primary-dim` (#425467) to add "soul" and a tactile, clickable quality.

---

## 3. Typography: The Editorial Authority

We use a dual-font strategy to balance high-end aesthetics with clinical readability.

*   **Display & Headline (Manrope):** A modern, geometric sans-serif that feels architectural and authoritative. Used for high-level stats (e.g., "98% Match Probability") and section headers.
*   **Body & Label (Inter):** A workhorse for legibility. Its tall x-height ensures that complex medical data and patient IDs remain readable at small sizes.

### Typographic Hierarchy
*   **Display-LG (3.5rem):** Reserved for hero metrics (Matching Scores).
*   **Headline-SM (1.5rem):** Used for Patient Names/Record Titles.
*   **Title-SM (1rem, Medium weight):** Used for table headers and card labels.
*   **Body-MD (0.875rem):** The standard for clinical notes and data entries.

---

## 4. Elevation & Depth: Tonal Layering

Traditional drop shadows are too "software-standard." We use **Ambient Shadows** and **Tonal Stacking**.

*   **The Layering Principle:** Instead of a shadow, place a `surface-container-lowest` (#ffffff) card on top of a `surface-container-high` (#e1eaed) background. The contrast in luminance creates a natural, soft lift.
*   **Ambient Shadows:** For critical floating elements (like an urgent notification), use a diffused shadow: `box-shadow: 0 12px 40px rgba(42, 52, 55, 0.06);`. The shadow color is a tint of our `on-surface` color, never pure black.
*   **The Ghost Border:** If a boundary is strictly required for accessibility (e.g., input fields), use the `outline-variant` (#a9b4b7) at **15% opacity**.

---

## 5. Components

### Cards & Data Lists
*   **Rule:** Forbid divider lines. 
*   **Execution:** Separate list items using `spacing-4` (0.9rem) or by alternating background colors between `surface-container-low` and `surface-container-lowest`. 
*   **Visuals:** Cards use a `DEFAULT` (0.25rem) or `md` (0.375rem) corner radius for a sharp, professional look.

### Buttons
*   **Primary:** Gradient fill (`primary` to `primary-dim`), `on-primary` text, `md` roundedness.
*   **Secondary:** `surface-container-highest` background with `on-surface` text. No border.
*   **Tertiary:** Ghost style. No background, `on-primary-container` text. High contrast on hover.

### Clinical Input Fields
*   **Style:** Minimalist. No bottom line or full border. Use a `surface-container-highest` (#d9e4e8) fill with a `sm` (0.125rem) bottom-accent of `primary` only when focused.
*   **Labels:** Always use `label-md` (#566164) positioned above the field for clear scanning.

### Specialized Components: The Match-Status Chip
*   **Matching Chips:** Use a `primary-container` (#d1e4fb) background with `on-primary-container` (#415366) text. For urgent status (e.g., Organ Decay Timer), use `error-container` (#fe8983) with `on-error-container` (#752121).

---

## 6. Do’s and Don’ts

### Do:
*   **Use Whitespace as a Separator:** Use the `spacing-8` (1.75rem) to `spacing-12` (2.75rem) scale to define large content blocks.
*   **Embrace Monochromatic Depth:** Use the 5 levels of `surface-container` to create a sophisticated, "stacked paper" look.
*   **Align to the Grid, then Break it:** Place key "Call to Action" elements or "Critical Alerts" slightly off-axis or overlapping container edges to draw immediate attention.

### Don’t:
*   **Don't use 100% Black:** It is too harsh for clinical environments. Use `on-surface` (#2a3437) for all primary text.
*   **Don't use Rounded 'Pill' Buttons:** Keep buttons at `md` (0.375rem) radius to maintain a serious, professional tone. 
*   **Don't use Icons for everything:** In a clinical setting, explicit text labels (e.g., "Review Match") are safer and more professional than ambiguous icons. Use icons only as supportive visual cues next to text.